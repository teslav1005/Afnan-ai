import { auth, db } from './api.js';
import { onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { collection, addDoc, query, where, getDocs, doc, updateDoc, orderBy, deleteDoc, arrayUnion, serverTimestamp, onSnapshot } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

let currentUser = null;
let currentChatId = null;
let pendingAttachment = null;
let currentModel = 'mistral-small-3.2';
let unsubscribeHistory = null;
let longPressTimer = null;
let activeContextChatId = null;

// Generator Settings (Backstage)
let genSettings = {
    type: 'image', // 'image' or 'video'
    model: 'nanobanana-2',
    size: '1:1',
    duration: 5,
    count: 1
};

const dom = {
    sidebar: document.getElementById('sidebar'),
    overlay: document.getElementById('overlay'),
    chatInput: document.getElementById('chatInput'),
    sendBtn: document.getElementById('sendBtn'),
    chatWindow: document.getElementById('chatWindow'),
    messageBox: document.getElementById('messageBox'),
    emptyView: document.getElementById('emptyView'),
    logoutConfirm: document.getElementById('logoutConfirm'),
    confirmYes: document.getElementById('confirmYes'),
    confirmNo: document.getElementById('confirmNo'),
    attachBtn: document.getElementById('mainAttachBtn'),
    newChatBtn: document.getElementById('newChatBtn'),
    historyList: document.getElementById('historyList'),
    attachmentPreview: document.getElementById('attachmentPreview'),
    imageViewer: document.getElementById('imageViewer'),
    viewerImg: document.getElementById('viewerImg'),
    modelSelectorTop: document.getElementById('modelSelectorTop'),
    currentModelBtn: document.getElementById('currentModelBtn'),
    modelDropdown: document.getElementById('modelDropdown'),
    activeModelName: document.getElementById('activeModelName'),
    historySearch: document.getElementById('historySearch'),
    contextMenu: document.getElementById('contextMenu'),
    pinnedList: document.getElementById('pinnedList'),
    favoritesList: document.getElementById('favoritesList'),
    recentList: document.getElementById('recentList'),
    pinnedSection: document.getElementById('pinnedSection'),
    favoritesSection: document.getElementById('favoritesSection'),
    generatorModal: document.getElementById('generatorModal'),
    genModel: document.getElementById('genModel'),
    videoOptions: document.getElementById('videoOptions'),
    imageOptions: document.getElementById('imageOptions'),
    generatorTitle: document.getElementById('generatorTitle'),
    genPrompt: document.getElementById('genPrompt'),
    genPreviewList: document.getElementById('genPreviewList'),
    genFileInput: document.getElementById('genFileInput')
};

const chatModels = [
    { id: 'mistral-small-3.2', name: 'mistral-small-3.2' },
    { id: 'mercury', name: 'Mercury 2' },
    { id: 'midijourney', name: 'midijourney' },
    { id: 'openai-large', name: 'Gpt-5.5' },
    { id: 'gemini-large', name: 'Gemini-3.1Pro' },
    { id: 'claude-large', name: 'Claude Opus 4.8' },
    { id: 'deepseek-pro', name: 'deepseek-v4-Pro' }
];

const imageModels = [
    { id: 'nanobanana-2', name: 'nanobanana-2' },
    { id: 'gpt-image-2', name: 'gpt-image-2' },
    { id: 'nova-canvas', name: 'nova-canvas' }
];

const videoModels = [
    { id: 'ltx-2', name: 'Ltx2.3' },
    { id: 'seedance-pro', name: 'seedance-pro' },
    { id: 'veo', name: 'Veo3.1' }
];

// Auth State Listener
onAuthStateChanged(auth, async (user) => {
    const loginBtnHeader = document.getElementById('loginBtnHeader');
    const profileSection = document.getElementById('profileSection');

    if (!user) {
        currentUser = null;
        if (loginBtnHeader) loginBtnHeader.style.display = 'block';
        dom.modelSelectorTop.classList.add('hidden');
        profileSection.innerHTML = '';
        dom.historyList.innerHTML = '';
        if (unsubscribeHistory) unsubscribeHistory();
    } else {
        currentUser = user;
        if (loginBtnHeader) loginBtnHeader.style.display = 'none';
        dom.modelSelectorTop.classList.remove('hidden');
        renderChatModels();
        profileSection.innerHTML = `
            <div id="profileTrigger" class="flex items-center gap-3 p-2.5 rounded-2xl cursor-pointer hover:bg-gray-200/50 transition-all">
                <img src="${user.photoURL || 'https://via.placeholder.com/40'}" class="w-10 h-10 rounded-full bg-black object-cover">
                <div class="flex-1 min-w-0 text-right">
                    <p class="text-xs font-bold truncate">${user.displayName || 'User'}</p>
                    <p class="text-[10px] text-gray-500 truncate">${user.email || ''}</p>
                </div>
                <i class="fa-solid fa-ellipsis-vertical text-gray-300 text-xs"></i>
            </div>
            <div id="profilePopup" class="glass p-2 space-y-1 hidden absolute bottom-[70px] left-[10px] w-[220px] z-[200] rounded-[1.5rem] shadow-xl">
                <a href="privacy.html" class="block p-3 text-sm hover:bg-gray-100 rounded-xl">سياسة الخصوصية</a>
                <a href="terms.html" class="block p-3 text-sm hover:bg-gray-100 rounded-xl">اتفاقية المستخدم</a>
                <button id="logoutBtn" class="w-full text-right p-3 text-sm hover:bg-gray-100 rounded-xl">تسجيل الخروج</button>
            </div>
        `;
        setupProfileListeners();
        listenToChatHistory();
    }
});

const renderChatModels = () => {
    const list = document.getElementById('chatModelsList');
    list.innerHTML = chatModels.map(m => `
        <div onclick="window.selectModel('${m.id}', '${m.name}')" class="p-3 hover:bg-white/50 rounded-xl cursor-pointer flex items-center justify-between transition-all">
            <span class="text-xs font-bold">${m.name}</span>
            ${currentModel === m.id ? '<i class="fa-solid fa-check text-black text-[10px]"></i>' : ''}
        </div>
    `).join('');
};

window.selectModel = (id, name) => {
    currentModel = id;
    dom.activeModelName.textContent = name;
    dom.modelDropdown.classList.add('hidden');
    renderChatModels();
    window.toast(`تم اختيار نموذج ${name}`);
};

const setupProfileListeners = () => {
    const trigger = document.getElementById('profileTrigger');
    const popup = document.getElementById('profilePopup');
    if (trigger) trigger.onclick = (e) => { e.stopPropagation(); popup.classList.toggle('hidden'); };
    document.getElementById('logoutBtn').onclick = () => {
        dom.logoutConfirm.classList.remove('hidden');
        popup.classList.add('hidden');
    };
    document.getElementById('confirmYes').onclick = async () => {
        await signOut(auth);
        dom.logoutConfirm.classList.add('hidden');
        window.location.reload();
    };
    document.getElementById('confirmNo').onclick = () => dom.logoutConfirm.classList.add('hidden');
};

// Generator Logic
window.openGenerator = (type) => {
    genSettings.type = type;
    dom.generatorTitle.textContent = type === 'image' ? 'توليد الصور' : 'توليد الفيديو';
    dom.videoOptions.classList.toggle('hidden', type === 'image');
    dom.imageOptions.classList.toggle('hidden', type === 'video');
    
    const models = type === 'image' ? imageModels : videoModels;
    dom.genModel.innerHTML = models.map(m => `<option value="${m.id}">${m.name}</option>`).join('');
    genSettings.model = models[0].id;
    
    dom.generatorModal.style.display = 'flex';
};

window.closeGenerator = () => {
    dom.generatorModal.style.display = 'none';
};

window.setGenSize = (size) => {
    genSettings.size = size;
    document.querySelectorAll('.size-opt').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.size === size);
    });
};

window.setGenDuration = (dur) => {
    genSettings.duration = dur;
    document.querySelectorAll('.dur-opt').forEach(btn => {
        btn.classList.toggle('active', parseInt(btn.dataset.dur) === dur);
    });
};

window.setGenCount = (count) => {
    genSettings.count = count;
    document.querySelectorAll('.count-opt').forEach(btn => {
        btn.classList.toggle('active', parseInt(btn.dataset.count) === count);
    });
};

dom.genFileInput.onchange = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
        const reader = new FileReader();
        reader.onload = (event) => {
            const div = document.createElement('div');
            div.className = 'relative shrink-0 w-16 h-16';
            div.innerHTML = `
                <img src="${event.target.result}" class="w-full h-full object-cover rounded-xl">
                <button onclick="this.parentElement.remove()" class="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white rounded-full flex items-center justify-center text-[8px]"><i class="fa-solid fa-xmark"></i></button>
            `;
            dom.genPreviewList.appendChild(div);
        };
        reader.readAsDataURL(file);
    });
};

// Sidebar Toggle
document.getElementById('sidebarToggle').onclick = () => {
    dom.sidebar.classList.remove('-translate-x-full');
    dom.overlay.classList.remove('hidden');
    dom.overlay.style.opacity = '1';
};

dom.overlay.onclick = () => {
    dom.sidebar.classList.add('-translate-x-full');
    dom.overlay.classList.add('hidden');
    dom.overlay.style.opacity = '0';
};

// Chat Logic
window.handleSend = async () => {
    const val = dom.chatInput.value.trim();
    if (!val && !pendingAttachment) return;
    if (!currentUser) { window.navigateToPage('login.html'); return; }

    dom.emptyView.style.display = 'none';
    appendMessage('user', val, pendingAttachment);
    
    const currentText = val;
    const currentAttach = pendingAttachment;
    const activeModel = currentModel;
    
    dom.chatInput.value = '';
    pendingAttachment = null;
    dom.attachmentPreview.classList.add('hidden');

    const typing = document.createElement('div');
    typing.className = 'flex justify-start mb-4';
    typing.innerHTML = `<div class="bg-white border border-gray-100 px-5 py-3.5 rounded-[1.8rem] rounded-tl-md shadow-sm"><div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div>`;
    dom.messageBox.appendChild(typing);
    dom.chatWindow.scrollTop = dom.chatWindow.scrollHeight;

    try {
        const aiRes = `هذا رد تجريبي من نموذج ${activeModel}.`;
        typing.remove();
        appendMessage('bot', aiRes);

        const msgUser = { sender: 'user', text: currentText, attachment: currentAttach, model: activeModel, timestamp: new Date() };
        const msgBot = { sender: 'bot', text: aiRes, timestamp: new Date() };

        if (!currentChatId) {
            const docRef = await addDoc(collection(db, 'chats'), {
                userId: currentUser.uid,
                title: currentText.substring(0, 30),
                messages: [msgUser, msgBot],
                updatedAt: serverTimestamp()
            });
            currentChatId = docRef.id;
        } else {
            await updateDoc(doc(db, 'chats', currentChatId), {
                messages: arrayUnion(msgUser, msgBot),
                updatedAt: serverTimestamp()
            });
        }
    } catch (e) { console.error(e); typing.remove(); }
};

const appendMessage = (sender, text, attachment) => {
    const div = document.createElement('div');
    div.className = sender === 'user' ? 'flex justify-end' : 'flex justify-start';
    
    let content = text;
    if (attachment) {
        if (attachment.type === 'image') content = `<img src="${attachment.data}" class="w-48 rounded-lg mb-2">${text}`;
        else content = `<div class="flex items-center gap-2 bg-gray-100 p-2 rounded-lg mb-2"><i class="fa-solid fa-file"></i><span>${attachment.name}</span></div>${text}`;
    }

    if (sender === 'user') {
        div.innerHTML = `<div class="bg-[#F4F4F4] px-5 py-3.5 rounded-[1.8rem] rounded-tr-md max-w-[80%] text-[14px]">${content}</div>`;
    } else {
        div.innerHTML = `<div class="bg-white border border-gray-100 px-5 py-3.5 rounded-[1.8rem] rounded-tl-md max-w-[80%] text-[14px] shadow-sm">${content}</div>`;
    }
    dom.messageBox.appendChild(div);
    dom.chatWindow.scrollTop = dom.chatWindow.scrollHeight;
};

// History logic
const listenToChatHistory = () => {
    const q = query(collection(db, 'chats'), where('userId', '==', currentUser.uid), orderBy('updatedAt', 'desc'));
    unsubscribeHistory = onSnapshot(q, (snap) => {
        dom.recentList.innerHTML = '';
        snap.forEach(docSnap => {
            const chat = docSnap.data();
            const id = docSnap.id;
            const item = document.createElement('div');
            item.className = `p-3 rounded-xl hover:bg-gray-100 cursor-pointer text-xs font-bold truncate ${currentChatId === id ? 'bg-gray-100' : ''}`;
            item.textContent = chat.title || 'محادثة جديدة';
            item.onclick = () => window.loadChat(id);
            dom.recentList.appendChild(item);
        });
    });
};

window.loadChat = async (id) => {
    currentChatId = id;
    dom.messageBox.innerHTML = '';
    dom.emptyView.style.display = 'none';
    const snap = await getDocs(query(collection(db, 'chats'), where('__name__', '==', id)));
    if (!snap.empty) {
        snap.docs[0].data().messages.forEach(msg => appendMessage(msg.sender, msg.text, msg.attachment));
    }
};

dom.mainAttachBtn.onclick = () => window.openGenerator('image');
dom.newChatBtn.onclick = () => {
    currentChatId = null;
    dom.messageBox.innerHTML = '';
    dom.emptyView.style.display = 'flex';
};

dom.sendBtn.onclick = window.handleSend;
dom.chatInput.onkeydown = (e) => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); window.handleSend(); } };

window.toast = (msg) => {
    const t = document.createElement('div');
    t.className = 'glass px-4 py-2 rounded-full text-xs fixed bottom-24 left-1/2 -translate-x-1/2 z-[5000] shadow-xl animate-pop';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 2000);
};

window.navigateToPage = (page) => window.location.href = page;
window.closeImageViewer = () => dom.imageViewer.classList.add('hidden');
window.openImageViewer = (src) => {
    dom.viewerImg.src = src;
    dom.imageViewer.classList.remove('hidden');
};
